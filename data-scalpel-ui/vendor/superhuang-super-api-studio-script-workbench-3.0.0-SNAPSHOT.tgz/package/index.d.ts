import type { ReactElement } from 'react';

export interface ScriptMethodCompletion {
  type?: string;
  varName: string;
  resultType?: string;
  params?: string;
  docs?: string;
}

export interface ScriptTableField {
  name: string;
  type?: string;
  comment?: string;
  [key: string]: unknown;
}

export interface ScriptTableCompletion {
  name: string;
  fields?: ScriptTableField[];
  [key: string]: unknown;
}

export interface ScriptCompletionData {
  clazzs: Record<string, ScriptMethodCompletion[]>;
  variables: Record<string, string>;
  syntax: Record<string, string>;
  dbInfos: Record<string, ScriptTableCompletion[]>;
  dataSourceId?: string;
}

export interface ScriptSourceLocation {
  line?: number;
  column?: number;
  endLine?: number;
  endColumn?: number;
  snippet?: string;
}

export interface ScriptExecutionError {
  code?: string;
  title?: string;
  message?: string;
  hint?: string;
  technicalMessage?: string;
  source?: ScriptSourceLocation;
}

export interface ScriptSqlTrace {
  statementId?: string;
  operation?: string;
  datasource?: string;
  sqlTemplate?: string;
  durationMs?: number;
  status?: string;
  rowCount?: number;
  rowsAffected?: number;
  error?: ScriptExecutionError;
}

export interface ScriptExecutionResult {
  data?: unknown;
  status?: 'RUNNING' | 'SUCCESS' | 'FAILED';
  durationMs?: number;
  logs?: string[];
  logEvents?: Array<{ level?: string; source?: string; message?: string }>;
  sqlTraces?: ScriptSqlTrace[];
  sqlCount?: number;
  error?: ScriptExecutionError;
}

export interface ScriptRequestParameter {
  id: string;
  key: string;
  value: string;
}

export interface ScriptRequestExample {
  id: string;
  name: string;
  bodyText: string;
  query: ScriptRequestParameter[];
  headers: ScriptRequestParameter[];
}

export interface ScriptRunRequest {
  body: unknown;
  query: Record<string, string>;
  headers: Record<string, string>;
}

export interface ScriptWorkbenchProps {
  value: string;
  onChange: (value: string) => void;
  onRun: (request: ScriptRunRequest) => Promise<ScriptExecutionResult>;
  completionData?: ScriptCompletionData | null;
  examples: ScriptRequestExample[];
  onExamplesChange: (examples: ScriptRequestExample[]) => void;
  readOnly?: boolean;
}

export declare function ScriptWorkbench(props: ScriptWorkbenchProps): ReactElement;
